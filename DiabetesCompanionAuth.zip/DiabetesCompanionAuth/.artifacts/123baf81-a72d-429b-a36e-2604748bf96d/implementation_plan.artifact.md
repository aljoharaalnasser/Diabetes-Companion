# Implementation Plan - Remove Admin from Sign-Up

The user wants to prevent users from selecting the "Admin" role during the sign-up process, while still allowing admins to sign in.

## Proposed Changes

### [Component Name]

#### [MODIFY] [AuthActivity.java](file:///Users/abdulahad/Desktop/DiabetesCompanionAuth/app/src/main/java/com/diabetescompanion/auth/AuthActivity.java)

- Update `showScreen()` to:
    - Hide the `role_admin` RadioButton when `signingUp` is true.
    - Show the `role_admin` RadioButton when `signingUp` is false.
    - If `signingUp` becomes true and the currently `selectedRole` is `R.id.role_admin`, reset `selectedRole` to `R.id.role_patient` and update the `RadioGroup` check.
- Keep `updateAdminNote()` as is for now, or consider if it's still needed. Since `role_admin` will be hidden during sign-up, `updateAdminNote()` will effectively always hide the note during sign-up.

### [Tests]

#### [MODIFY] [AuthSmokeTest.java](file:///Users/abdulahad/Desktop/DiabetesCompanionAuth/app/src/androidTest/java/com/diabetescompanion/auth/AuthSmokeTest.java)

- Update the test loop to skip `role_admin` when `signup` is true.
- Update the assertion for `admin_note` visibility if necessary (though if we skip the role it might be fine).
- Alternatively, keep the loop and assert that `role_admin` is `GONE` during sign-up.

### Manual Verification
1.  Launch the app (it starts on sign-up screen by default).
2.  Verify that "Admin" role is NOT visible.
3.  Switch to Sign-In screen.
4.  Verify that "Admin" role IS visible.
5.  Switch back to Sign-Up screen.
6.  Verify that "Admin" role is NOT visible again.
7.  Select "Admin" on Sign-In screen, then switch to Sign-Up screen.
8.  Verify that the selection automatically changes to "Patient" (or another non-admin role) and "Admin" is hidden.
